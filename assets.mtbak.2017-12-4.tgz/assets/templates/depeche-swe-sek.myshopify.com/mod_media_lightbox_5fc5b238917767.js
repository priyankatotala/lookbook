if(typeof myAppJavaScriptmodLookbook != "function"){
var myAppJavaScriptmodLookbook = function($) {
var pages = [    
        {
        page: '1',
        image: {"file_name":"lookbook-modmedia-3067-page-31839.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31839.jpg?6289733079476385847","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:423.27,
                left:242.77,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1457431042.9875.jpg?v=1471861362",
                handle: "paris-perfection-small-bag-clutch-small-bag-clutch-2"
                }
                        ]}
        ,        {
        page: '2',
        image: {"file_name":"lookbook-modmedia-3067-page-31840.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31840.jpg?13694010186242065143","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:430.82,
                left:295.60,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1459931730.0674.jpg?v=1473177029",
                handle: "catwalk-classic-medium-bag-medium-bag-1"
                }
                        ]}
        ,        {
        page: '3',
        image: {"file_name":"lookbook-modmedia-3067-page-31841.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31841.jpg?15452512814649647563","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:155.35,
                left:415.09,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1472128267.7502.jpg?v=1472455670",
                handle: "jacket-jackets-2"
                }
                        ]}
        ,        {
        page: '4',
        image: {"file_name":"lookbook-modmedia-3067-page-31842.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31842.jpg?15877126384758826725","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:223.27,
                left:301.89,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1471869969.0905.jpg?v=1471870062",
                handle: "jacket-jackets"
                }
                        ]}
        ,        {
        page: '5',
        image: {"file_name":"lookbook-modmedia-3067-page-31843.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31843.jpg?6020636336838658469","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:156.60,
                left:304.40,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1471870039.1351.jpg?v=1472214174",
                handle: "scarf-jackets"
                }
                        ]}
        ,        {
        page: '6',
        image: {"file_name":"lookbook-modmedia-3067-page-31844.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31844.jpg?9443214577722715026","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:237.11,
                left:274.21,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1471869801.528.jpg?v=1471869883",
                handle: "jacket-jackets-1"
                }
                        ]}
        ,        {
        page: '7',
        image: {"file_name":"lookbook-modmedia-3067-page-31845.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31845.jpg?10518856005224616922","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:415.72,
                left:548.43,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1459929158.2363.jpg?v=1471861152",
                handle: "winter-vintage-medium-bag-medium-bag"
                }
                        ]}
        ,        {
        page: '8',
        image: {"file_name":"lookbook-modmedia-3067-page-31846.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31846.jpg?3152774915881417469","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:466.04,
                left:628.93,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1459934496.2363.jpg?v=1471861473",
                handle: "tailored-taste-cross-over-cross-over-1"
                }
                ,                {
                item:2,
                top:408.18,
                left:571.07,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1449835553.6538.jpg?v=1471860831",
                handle: "narrow-belt-studs-belts-6"
                }
                ,                {
                item:3,
                top:242.14,
                left:476.73,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1471935689.4681.jpg?v=1471935762",
                handle: "biker-jacket-jackets-1"
                }
                        ]}
        ,        {
        page: '9',
        image: {"file_name":"lookbook-modmedia-3067-page-31847.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31847.jpg?17943248747544199446","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:258.49,
                left:689.31,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1471935791.4777.jpg?v=1471935883",
                handle: "jacket-jackets-3"
                }
                        ]}
        ,        {
        page: '10',
        image: {"file_name":"lookbook-modmedia-3067-page-31848.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31848.jpg?9751628906278305535","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:464.78,
                left:520.75,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1459934339.5218.jpg?v=1471861446",
                handle: "divine-design-cross-over-cross-over-1"
                }
                ,                {
                item:2,
                top:248.43,
                left:325.79,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1471863709.422.jpg?v=1473320763",
                handle: "biker-jacket-jackets-2"
                }
                        ]}
        ,        {
        page: '11',
        image: {"file_name":"lookbook-modmedia-3067-page-31849.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31849.jpg?12698485129126278423","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:294.97,
                left:177.36,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1459929579.7235.jpg?v=1471861171",
                handle: "avantgarde-avenue-cross-over-cross-over"
                }
                        ]}
        ,        {
        page: '12',
        image: {"file_name":"lookbook-modmedia-3067-page-31850.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31850.jpg?5289262891822095530","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:244.65,
                left:616.35,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1471935943.6629.jpg?v=1472120937",
                handle: "winter-jacket-jackets"
                }
                ,                {
                item:2,
                top:376.73,
                left:553.46,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1449836489.0202.jpg?v=1471860890",
                handle: "jeans-belt-basic-belts-6"
                }
                        ]}
        ,        {
        page: '13',
        image: {"file_name":"lookbook-modmedia-3067-page-31851.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31851.jpg?18243268460779337613","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:453.46,
                left:236.48,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1459935724.7061.jpg?v=1471861514",
                handle: "casual-chic-small-bag-clutch-small-bag-clutch-4"
                }
                ,                {
                item:2,
                top:317.61,
                left:207.55,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "https://cdn.shopify.com/s/files/1/1448/3678/products/1472128337.3934.jpg?v=1472472848",
                handle: "jacket-jackets-6"
                }
                        ]}
        ,        {
        page: '14',
        image: {"file_name":"lookbook-modmedia-3067-page-31852.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31852.jpg?14631523365557386843","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        ]}
        ,        {
        page: '15',
        image: {"file_name":"lookbook-modmedia-3067-page-31853.jpg","full_path":"https:\/\/cdn.shopify.com\/s\/files\/1\/1448\/3678\/t\/3\/assets\/lookbook-modmedia-3067-page-31853.jpg?18126605559783808857","image_width":800,"image_height":600,"file_ext":".jpg"},
        products: [
                        {
                item:1,
                top:223.27,
                left:344.65,
                link_target:'_self',
                linkto:1,
                url:"",
                custom_title:"",
                show_image:"1",
                show_title:"1",
                show_price:"1",
                icon:"https://cdn.shopify.com/s/files/1/1448/3678/t/3/assets/lb_mm_circle_237102710_2552552550.png?2535283868557767880",
                icon_width: "26",
                icon_height: "26",
                image: "//cdn.shopify.com/s/assets/image-upload-899ed12e0ca7dd5ac65df627c3b5bf54.png",
                handle: ""
                }
                        ]}
        ];
var css = "#lookbook-modmedia-3067 .fflex-control-paging li a { } #lookbook-modmedia-3067 .fflex-control-paging li a:hover {} #lookbook-modmedia-3067 .fflex-control-paging li a.fflex-active {}";
var style = document.createElement('style');

style.type = 'text/css';
if (style.styleSheet){
style.styleSheet.cssText = css;
} else {
style.appendChild(document.createTextNode(css));
}
document.getElementsByTagName("head")[0].appendChild(style);

if((typeof Shopify) == 'undefined'){
if ((typeof Shopify) == 'undefined') {
var Shopify = {};
}
/* ---------------------------------------------------------------------------
* Money format handler single/slideshow
* ---------------------------------------------------------------------------*/
Shopify.money_format = "$ {{amount}}";
Shopify.formatMoney = function(cents, format) {
if (typeof cents == 'string') cents = cents.replace('.','');
var value = '';
var patt = /\{\{\s*(\w+)\s*\}\}/;
var formatString = (format || this.money_format);

function addCommas(moneyString) {
return moneyString.replace(/(\d+)(\d{3}[\.,]?)/,'$1,$2');
}

switch(formatString.match(patt)[1]) {
case 'amount':
value = addCommas(floatToString(cents/100.0, 2));
break;
case 'amount_no_decimals':
value = addCommas(floatToString(cents/100.0, 0));
break;
case 'amount_with_comma_separator':
value = floatToString(cents/100.0, 2).replace(/\./, ',');
break;
case 'amount_no_decimals_with_comma_separator':
value = addCommas(floatToString(cents/100.0, 0)).replace(/\./, ',');
break;
}
return formatString.replace(patt, value);
};

function floatToString(numeric, decimals) {  
var amount = numeric.toFixed(decimals).toString();  
if(amount.match(/^\.\d+/)) {return "0"+amount; }
else { return amount; }
};

}
(function ($, document, undefined) {
$.modresize=function(){
$('.modmedia-image').each(function() {
var image_width = $(this).attr('data-width');
var image_height = $(this).attr('data-height');
var ratio = Math.round(($(this).width() / image_width) * 1000) / 1000;
if(ratio <0.5){ ratio_resize=0.5;}else{ ratio_resize=ratio;}
$(this).parent().find('.lookbook-item').each(function() {
$(this).width($(this).attr('data-width') * ratio_resize);
$(this).height($(this).attr('data-height') * ratio_resize);
var top = Math.round($(this).attr('data-top') / (image_height) * 1000) / 1000;
var left = Math.round($(this).attr('data-left') / (image_width) * 1000) / 1000;
$(this).css({
top: top * ratio * image_height,
left: left * ratio * image_width
});
});
});
};
var flexslider_container=$('<div  id="lookbook-modmedia-3067" class="lookbook-modmedia-container"></div>');
var flexsliderwr=$('<div class="lookbook-modmedia-flexslider"></div>');
var ul_pages=$('<ul class="lookbook_slides"></ul>');
$('#lookbook-modmedia-container').append(flexslider_container);
var list_pages='';
if(pages.length == 0){
ul_pages.append('<li>There is no pages in this Lookbook.</li>');
}else{
$.each(pages, function(page_index){
list_pages=$('<li></li>');
var page_image='';
var page_image_width=0;
var page_image_height=0;
if(pages[page_index].image['full_path']!== undefined){
page_image='<img src="' + pages[page_index].image['full_path'] + '" alt="Main image"/>';
page_image_width=pages[page_index].image['image_width'];
page_image_height=pages[page_index].image['image_height'];
}
var modimage=$('<div class="modmedia-image" data-width="'+page_image_width + '" data-height="' + page_image_height + '" style="max-width:'+page_image_width + 'px;">'+page_image+'</div>');
var hovers=$('<div class="hovers"></div>');
var products=pages[page_index].products;
var page=pages[page_index].page;
$.each(products, function(prod){
var display_image='';
if(products[prod].show_image == 1){
display_image='<div class="modmedia-lookbook-product-image"><img style="max-width:150px; max-height:150px;" src="' + products[prod].image + '" alt="' + products[prod].handle + '"/></div>';
}
var display_name_price='';
if(products[prod].show_title == 1){
display_name_price='<div class="name"></div>';
}
if(products[prod].show_price == 1){
display_name_price+='<div class="price"></div>';
}
if(display_name_price!=''){
display_name_price='<div class="name-price">'+display_name_price+'</div>';
}
var pin='<a href="'+products[prod].url+'" target="'+products[prod].link_target+'"><img src="'+products[prod].icon+'" alt="+"/></a>';
hovers.append('<div id="pin-'+page+'-'+products[prod].item+'" data-container="modmedia-lookbook-item-hover" class="lookbook-item pin-'+page+'-'+products[prod].item+'" data-item="'+prod+'" data-width="'+products[prod].icon_width+'" data-height="'+products[prod].icon_height+'" data-id="'+products[prod].item+'" data-top="'+products[prod].top+'" data-left="'+products[prod].left+'" data-image="'+products[prod].image+'" data-name="" data-linkto="'+products[prod].linkto+'" data-link_target="'+products[prod].link_target+'" data-url="'+products[prod].url+'" data-handle="'+products[prod].handle+'" data-price="" data-custom_title="'+products[prod].custom_title+'" style="top:'+products[prod].top+'px; left:'+products[prod].left+'px;">'+pin+'<div id="modhover-pin-'+page+'-'+products[prod].item+'" class="modhover-pin-'+page+'-'+products[prod].item+' modmedia-lookbook-item-hover ml-item-hover-autumn-winter-collection-2017">'+display_image+display_name_price+'</div>'+'</div>');
});
modimage.append(hovers);
list_pages.append(modimage);                      
ul_pages.append(list_pages);              
});
}
flexslider_container.append(flexsliderwr);
flexsliderwr.append(ul_pages);
$('.lookbook-modmedia-flexslider').flexslider({
namespace: "fflex-",
selector: ".lookbook_slides > li",   
animation: "slide",
animationLoop: true,
slideshow: false,
start:function(){
$(window).resize();
},
before:function(){
$('.modmedia-lookbook-item-hover').hide();                
}
});
$( "#lookbook-modmedia-container img" ).load(function() {
$(window).resize();
}); 
$(window).resize(function() {
$.modresize();
});
$(window).load(function() {
$.modresize();
});
$.check_loaded=function(e, obj, value){
var item=obj.attr('id');
var hover_product=$('.modhover-'+item);
if(obj.attr('data-loaded')=='1'){
$.positionBox(e, obj, hover_product);
}else{
if(hover_product.find('.name')){
if(value=='name'){
obj.attr('nameloaded',1);
}
}else{
obj.attr('nameloaded',1);
}
if(hover_product.find('.price')){
if(value=='price'){
obj.attr('priceloaded',1);
}
}else{
obj.attr('priceloaded',1);
}
if(obj.attr('nameloaded') == 1 && obj.attr('priceloaded') == 1){
obj.removeAttr('nameloaded');
obj.removeAttr('priceloaded');
obj.removeAttr('imageloaded');
obj.attr('data-loaded',1);
obj.parent().find('.loading-look-product').remove();
$.positionBox(e, obj, hover_product);
}
}
};
/* shreeji add code start for mobile device */
    $('.lookbook-item').click(function() {
        if($("#"+$(this).attr('id')+' a').attr('href')==""||$("#"+$(this).attr('id')+' a').attr('href')=="undefined"){
            return false;
        } else{
            var item=$(this).attr('id');
            var link=$('<a href ="'+$(this).attr('data-url')+'" target="'+$(this).attr('data-link_target')+'"></a>');
            link[0].click();
            return true;
        }

    });   
/* shreeji add code end for mobile device */
$('.lookbook-item').mouseover(function(e) {
var thise=e;
var thisobj=$(this);
var item=$(this).attr('id');
var hover_product=$('.modhover-'+item);
if($(this).find('.modhover-'+item).length>0){
if($('.modhover-'+item).length>1){
$('.modhover-'+item).eq(1).remove();
hover_product=$('.modhover-'+item);
}
hover_product.appendTo($('body'));
}
$('.modmedia-lookbook-item-hover:not('+'.modhover-'+item+')').fadeOut();
if($(this).attr('data-handle')!=''){
if($(this).attr('data-name')==''){
var loadingtxt=$('<div class="loading-look-product">Loading...</div>');
$(this).parent().append(loadingtxt);
loadingtxt.css({
top:$(this).position().top + 20,
left:$(this).position().left + 20,
position:'absolute'
});
hover_product.find('.name').hide();
hover_product.find('.price').hide();
var handle=$(this).attr('data-handle');
$.ajax({
url:'/products/'+handle+'.js',
type:'GET',
dataType:'json',
success:function(data){
if(hover_product.find('.name')){
if($('#'+item).attr('data-custom_title') != ''){
$('#'+item).attr('data-name',$('#'+item).attr('data-custom_title'));
}else{
$('#'+item).attr('data-name',data.title);
}
hover_product.find('.name').text($('#'+item).attr('data-name'));
hover_product.find('.name').fadeIn();
$.check_loaded(e, thisobj, 'name');
}
if(hover_product.find('.price')){
var price='';
if(data.price_varies){
price='<span class="from">from:</span> <span class="price_value">'+Shopify.formatMoney(data.price_min,modlookbook_money_with_currency_format)+'</span>';
}else{
price='<span class="price_value">'+Shopify.formatMoney(data.price,modlookbook_money_with_currency_format)+'</span>';
}
if(data.compare_at_price > 0){
if(data.compare_at_price_varies){
if(data.price_min != data.compare_at_price_min || data.price_max != data.compare_at_price_max){
price=price+'<em class="compare_at_price">'+Shopify.formatMoney(data.compare_at_price_min,modlookbook_money_with_currency_format)+'</em>';
}
}else{
if(data.price != data.compare_at_price){
price=price+'<em class="compare_at_price">'+Shopify.formatMoney(data.compare_at_price,modlookbook_money_with_currency_format)+'</em>';
}
}
}
$('#'+item).attr('data-price',price);
hover_product.find('.price').html(price);
hover_product.find('.price').fadeIn();
$.check_loaded(e, thisobj, 'price');
}
if($('#'+item).attr('data-linkto')=="1"){
$('#'+item).attr('data-url',data.url);
$('#'+item+' a').attr('href',data.url);
}
hover_product.wrapInner('<a href="'+data.url+'" target="'+$('#'+item).attr('data-link_target')+'"></a>');
$(window).resize();
},
error:function(x,e){
thisobj.parent().find('.loading-look-product').remove();
}
});
}else{
hover_product.find('.name').html($(this).attr('data-name'));
hover_product.find('.price').html($(this).attr('data-price'));
$(window).resize();
}                
}else{

                if($(this).find('.modhover-'+item).length>0){
                    if($('.modhover-'+item).length>1){
                        $('.modhover-'+item).eq(1).remove();
                        hover_product=$('.modhover-'+item);
                    }
                    hover_product.appendTo($('body'));
                }
                if($(this).attr('data-custom_title')!=''){              
                    hover_product.find('.name').hide();
                    hover_product.find('.price').hide();
                    hover_product.find('.name').text($(this).attr('data-custom_title'));
                    hover_product.find('.name').fadeIn();
                    thisobj.attr('data-loaded',1);
                }
                /*added by shree for iphone*/
                if($(this).attr('data-handle')==''){
                  if (navigator.userAgent.match(/(iPod|iPhone|iPad)/)) 
                      window.location=$(this).attr('data-url');
                }
                /*added by shree for iphone*/
            }
$.check_loaded(e, thisobj, '');
});
$.positionBox=function(e, obj, hover_product){
hover_product.css({
visibility: "hidden",
display: "block"
});
var win = $(window);
var viewport = {
top : win.scrollTop(),
left : win.scrollLeft()
};
viewport.right = viewport.left + win.width();
viewport.bottom = viewport.top + win.height();

var left=e.pageX+ (obj.outerWidth()/2);
var top=e.pageY + (obj.outerHeight()/2);

hover_product.css({
position:'absolute',
top: top,
left: left                
});

var bounds = hover_product.offset();
bounds.right = bounds.left + hover_product.outerWidth();
bounds.bottom = bounds.top + hover_product.outerHeight();
if(bounds.right > win.width()){
left=e.pageX - (bounds.right-viewport.right); 
}

if(bounds.bottom > win.height()){
newtop=e.pageY - hover_product.outerHeight() - (obj.outerHeight()/2);
if(newtop > viewport.top){
top=newtop;
}
}
hover_product.css({
position:'absolute',
top: top,
left: left
});
hover_product.css({
visibility: "visible",
display: "block"
});
hover_product.fadeIn();
obj.mousemove();
};
$('.lookbook-item').mousemove(function(e){
var item=$(this).attr('id');
var hover_product=$('.modhover-'+item);

var win = $(window);
var viewport = {
top : win.scrollTop(),
left : win.scrollLeft()
};
viewport.right = viewport.left + win.width();
viewport.bottom = viewport.top + win.height();

var left=e.pageX+ ($(this).outerWidth()/2);
var top=e.pageY + ($(this).outerHeight()/2);

hover_product.css({
position:'absolute',
top: top,
left: left
});

var bounds = hover_product.offset();
bounds.right = bounds.left + hover_product.outerWidth();
bounds.bottom = bounds.top + hover_product.outerHeight();
if(bounds.right > win.width()){
left=e.pageX - (bounds.right-viewport.right); 
}

if(bounds.bottom > win.height()){
newtop=e.pageY - hover_product.outerHeight() - ($(this).outerHeight()/2);
if(newtop > viewport.top){
top=newtop;
}
}
hover_product.css({
position:'absolute',
top: top,
left: left
});
});
var timers={};
$('.lookbook-item').mouseout(function() {
var item=$(this).attr('id');
var hover_product=$('.modhover-'+item);
timers['i-'+item]=setTimeout(function(){ hover_product.fadeOut();},200);
});
$('.modmedia-lookbook-item-hover').mouseover(function(){
var id=$(this).attr('id');
$('.'+id).fadeIn(0);
var item=id.replace('modhover-','');
if((typeof timers['i-'+item]) !== 'undefined'){
clearTimeout(timers['i-'+item]);
}
$('.modmedia-lookbook-item-hover:not('+'.'+id+')').fadeOut();            
});
$('.modmedia-lookbook-item-hover').mouseout(function(){
var id=$(this).attr('id');
var item=id.replace('modhover-','');
timers['i-'+item]=setTimeout(function(){ $('#'+id).fadeOut();},100);
});
})(modlookbookjQuery, document);
};
set_modlookbookjquery();
}