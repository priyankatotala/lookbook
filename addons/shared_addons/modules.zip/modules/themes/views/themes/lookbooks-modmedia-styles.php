<?php
$days=60;
$expires = 60*60*24*$days;
header("Pragma: public");
header("Cache-Control: max-age=".$expires);
header('Expires: ' . gmdate('D, d M Y H:i:s', time()+$expires) . ' GMT');
header('Last-Modified: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');
?>
.look-container {max-width:1170px; margin:0 auto}
.lookbook-modmedia-container{ display:block; padding:0px; margin:0px; position: relative;}
#lookbook-modmedia-container ul,.lookbook-modmedia-container ul{ list-style: none; padding: 0px; margin: 0px;}
#modmedia-lookbooks ul li{ margin-bottom: 20px; text-align: center; position: static; list-style-type:none;}
#modmedia-lookbooks ul li:before{ content:''; margin:0px; padding:0px;}
.lookbook-modmedia-container .modmedia-image{ position:relative; display:inline-block; *display:inline; /*float:left;*/ max-width:100% !important;}
.modmedia-lookbook-product-image img{ width:auto; height:auto;}
.lookbook-modmedia-container ul li a{ display:block; margin-bottom:20px;}
.lookbook-modmedia-container ul li img{ max-width: 100%; /*display:block;*/border:none; padding:0px; margin:0px; vertical-align:top;}
// Styles for Firefox
@-moz-document url-prefix() {
    .lookbook-modmedia-container ul li img {
        width: 100%;
    }
}

// Styles for IE10
@media screen and (-ms-high-contrast: active), (-ms-high-contrast: none) {
    .lookbook-modmedia-container ul li img {
        width: 100%;
    }
}
.modmedia-lookbook-item-hover{ display: none; position: absolute; background: #FFF; border: 1px solid #FFF; box-shadow: 1px 1px 4px 0px rgba(0,0,0,0.24); -webkit-box-shadow: 1px 1px 4px 0px rgba(0,0,0,0.24); -moz-box-shadow: 1px 1px 4px 0px rgba(0,0,0,0.24); z-index: 99999999; padding: 10px; overflow:hidden; max-width:250px;}
.modmedia-lookbook-item-hover a{text-decoration:none;}
.modmedia-lookbook-item-hover .name{ transition: width 1s, height 1s, transform 1s; -webkit-transition: width 1s, height 1s, -webkit-transform 1s;}
.modmedia-lookbook-item-hover em.compare_at_price{ padding:0px 5px; text-decoration:line-through; color:#CCC;}
.modmedia-lookbook-product-image{ height: 150px; text-align: center; margin-bottom: 5px;}
.lookbook-modmedia-container .lookbook-item{ cursor: pointer; overflow:hidden;}
.lookbook-modmedia-container  .hovers { position: absolute; top: 0px; left: 0px;}
.lookbook-modmedia-container .lookbook-item { width: 26px; height: 26px; position: absolute; cursor: pointer; box-sizing: border-box; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; opacity:0.5; filter: alpha(opacity=50);-moz-opacity: 0.5;}
.lookbook-modmedia-container .lookbook-item:hover { opacity:1; filter: alpha(opacity=100);-moz-opacity: 1;}

/*Lightbox*/
#modlbox-container{padding:0.1px; line-height:1px;*background: #FFF;background: #FFF;}
#modlbox-container img{margin:0px;border:none;padding:0px;width:100%;}
#modlbox-mailchimp{position:absolute;-webkit-transition:all 0.5s;-moz-transition:all 0.5s;transition:all 0.5s;}
#modlbox-container.mobil{padding:0px; }
#modlbox-subscribe{text-shadow:none;}
#modlbox-mailchimp form{ margin:0px;}
#modlbox-container.mobil #modlbox-mailchimp{position:relative !important;top:inherit !important;left:inherit !important;bottom:inherit !important;right:inherit !important;text-align:center !important;padding:10px !important;}
.lookbook-modmedia-popup {position: relative;background: none;width:auto;max-width: 90%;margin: 20px auto;-webkit-box-shadow: 0px 0px 3px 0px rgba(0,0,0,0.53);-moz-box-shadow: 0px 0px 3px 0px rgba(0,0,0,0.53);box-shadow: 0px 0px 3px 0px rgba(0,0,0,0.53);}
.modlbx-mfp-bg {top: 0;left: 0;width: 100%;height: 100%;z-index: 999999;overflow: hidden;position: fixed;*background: #FFFFFF;background: #FFFFFF;}
.modlbx-mfp-wrap {top: 0;left: 0;width: 100%;height: 100%;z-index: 9999999;position: fixed;outline: none !important;-webkit-backface-visibility: hidden;}

.modlbx-mfp-container {text-align: center;position: absolute;width: 100%;height: 100%;left: 0;top: 0;padding: 20px;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box; }
.modlbx-mfp-container:before {content: '';display: inline-block;height: 100%;vertical-align: middle;}.modlbx-mfp-align-top .modlbx-mfp-container:before {display: none; }
.modlbx-mfp-content {position: relative;display: inline-block;vertical-align: middle;margin: 0 auto;text-align: left;padding:0px;z-index: 9045; }
.modlbx-mfp-inline-holder .modlbx-mfp-content,.modlbx-mfp-ajax-holder .modlbx-mfp-content {width: 100%;cursor: auto; }
.modlbx-mfp-ajax-cur {cursor: progress; }.modlbx-mfp-zoom-out-cur,.modlbx-mfp-zoom-out-cur .modlbx-mfp-image-holder .modlbx-mfp-close {cursor: -moz-zoom-out;cursor: -webkit-zoom-out;cursor: zoom-out; }
.modlbx-mfp-zoom {cursor: pointer;cursor: -webkit-zoom-in;cursor: -moz-zoom-in;cursor: zoom-in; }
.modlbx-mfp-auto-cursor .modlbx-mfp-content {cursor: auto; }
.modlbx-mfp-close,.modlbx-mfp-arrow,.modlbx-mfp-preloader,.modlbx-mfp-counter {-webkit-user-select: none;-moz-user-select: none;user-select: none; }
.modlbx-mfp-loading.modlbx-mfp-figure {display: none; }.modlbx-mfp-hide {display: none !important; }
.modlbx-mfp-preloader {color: #cccccc;position: absolute;top: 50%;width: auto;text-align: center;margin-top: -0.8em;left: 8px;right: 8px;z-index: 9044; }
.modlbx-mfp-preloader a {color: #cccccc; }
.modlbx-mfp-preloader a:hover {color: white; }
.modlbx-mfp-s-ready .modlbx-mfp-preloader {display: none; }
.modlbx-mfp-s-error .modlbx-mfp-content {display: none; }
button.modlbx-mfp-close,button.modlbx-mfp-arrow {overflow: visible;cursor: pointer;background: transparent;border: 0;-webkit-appearance: none;display: block;padding: 0;z-index: 9046; }
button.modlbx-mfp-close::-moz-focus-inner,button.modlbx-mfp-arrow::-moz-focus-inner {padding: 0;border: 0; }
.modlbx-mfp-close {width: 30px;min-width: 30px;height: 30px;line-height: 30px;position: absolute;right: 0;top: 0;text-decoration: none;text-align: center;opacity: 0.65;padding: 0 0 18px 10px;color: white;font-style: normal;font-size: 28px;font-family: Arial, Baskerville, monospace; outline: none; }
.modlbx-mfp-close:hover, .modlbx-mfp-close:focus {opacity: 1; }
.modlbx-mfp-close:active {top: 1px; }
.modlbx-mfp-close-btn-in .modlbx-mfp-close {color: #333333; }
.modlbx-mfp-image-holder .modlbx-mfp-close,.modlbx-mfp-iframe-holder .modlbx-mfp-close {color: white;right: -6px;text-align: right;padding-right: 6px;width: 100%; }
.modlbx-mfp-counter {position: absolute;top: 0;right: 0;color: #cccccc;font-size: 12px;line-height: 18px; }
.modlbx-mfp-arrow {position: absolute;opacity: 0.65;margin: 0;top: 50%;margin-top: -55px;padding: 0;width: 90px;height: 110px;-webkit-tap-highlight-color: rgba(0, 0, 0, 0); }
.modlbx-mfp-arrow:active {margin-top: -54px; }
.modlbx-mfp-arrow:before, .modlbx-mfp-arrow:after,.modlbx-mfp-arrow .modlbx-mfp-b,.modlbx-mfp-arrow .modlbx-mfp-a {content: '';display: block;width: 0;height: 0;position: absolute;left: 0;top: 0;margin-top: 35px;margin-left: 35px;border: medium inset transparent; }
.modlbx-mfp-arrow:after,.modlbx-mfp-arrow .modlbx-mfp-a {border-top-width: 13px;border-bottom-width: 13px;top: 8px; }
.modlbx-mfp-arrow:before,.modlbx-mfp-arrow .modlbx-mfp-b {border-top-width: 21px;border-bottom-width: 21px; }
.modlbx-mfp-arrow-left {left: 0; }.modlbx-mfp-arrow-left:after,.modlbx-mfp-arrow-left .modlbx-mfp-a {border-right: 17px solid white;margin-left: 31px; }
.modlbx-mfp-arrow-left:before,.modlbx-mfp-arrow-left .modlbx-mfp-b {margin-left: 25px;border-right: 27px solid #3f3f3f; }
.modlbx-mfp-arrow-right {right: 0; }.modlbx-mfp-arrow-right:after,.modlbx-mfp-arrow-right .modlbx-mfp-a {border-left: 17px solid white;margin-left: 39px; }
.modlbx-mfp-arrow-right:before,.modlbx-mfp-arrow-right .modlbx-mfp-b {border-left: 27px solid #3f3f3f; }
.modlbx-mfp-iframe-holder {padding-top: 40px;padding-bottom: 40px; }
.modlbx-mfp-iframe-holder .modlbx-mfp-content {line-height: 0;width: 100%;max-width: 900px; }
.modlbx-mfp-iframe-scaler {width: 100%;height: 0;overflow: hidden;padding-top: 56.25%; }
.modlbx-mfp-iframe-scaler iframe {position: absolute;display: block;top: 0;left: 0;width: 100%;height: 100%;box-shadow: 0 0 8px rgba(0, 0, 0, 0.6);background: black; }
.modlbx-mfp-iframe-holder .modlbx-mfp-close {top: -40px; }img.modlbx-mfp-img {width: auto;max-width: 100%;height: auto;display: block;line-height: 0;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;padding: 40px 0 40px;margin: 0 auto; }
.modlbx-mfp-figure:after {content: '';position: absolute;left: 0;top: 40px;bottom: 40px;display: block;right: 0;width: auto;height: auto;z-index: -1;box-shadow: 0 0 8px rgba(0, 0, 0, 0.6);background: #444444; }
.modlbx-mfp-figure {line-height: 0; }
.modlbx-mfp-bottom-bar {margin-top: -36px;position: absolute;top: 100%;left: 0;width: 100%;cursor: auto; }
.modlbx-mfp-title {text-align: left;line-height: 18px;color: #f3f3f3;word-wrap: break-word;padding-right: 36px; }
.modlbx-mfp-figure small {color: #bdbdbd;display: block;font-size: 12px;line-height: 14px; }
.modlbx-mfp-image-holder .modlbx-mfp-content {max-width: 100%; }
.modlbx-mfp-gallery .modlbx-mfp-image-holder .modlbx-mfp-figure {cursor: pointer; }
@media screen and (max-width: 800px) and (orientation: landscape), screen and (max-height: 300px) {.modlbx-mfp-img-mobile .modlbx-mfp-image-holder {padding-left: 0;padding-right: 0; }.modlbx-mfp-img-mobile img.modlbx-mfp-img {padding: 0; }.modlbx-mfp-img-mobile .modlbx-mfp-figure:after {top: 0;bottom: 0; }.modlbx-mfp-img-mobile .modlbx-mfp-bottom-bar {background: rgba(0, 0, 0, 0.6);bottom: 0;margin: 0;top: auto;padding: 3px 5px;position: fixed;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box; }.modlbx-mfp-img-mobile .modlbx-mfp-bottom-bar:empty {padding: 0; }.modlbx-mfp-img-mobile .modlbx-mfp-counter {right: 5px;top: 3px; }.modlbx-mfp-img-mobile .modlbx-mfp-close {top: 0;right: 0;width: 35px;height: 35px;line-height: 35px;background: rgba(0, 0, 0, 0.6);position: fixed;text-align: center;padding: 0; }.modlbx-mfp-img-mobile .modlbx-mfp-figure small {display: inline;margin-left: 5px; } }
@media all and (max-width: 900px) {.modlbx-mfp-arrow {-webkit-transform: scale(0.75);transform: scale(0.75); }.modlbx-mfp-arrow-left {-webkit-transform-origin: 0;transform-origin: 0; }.modlbx-mfp-arrow-right {-webkit-transform-origin: 100%;transform-origin: 100%; }.modlbx-mfp-container {padding-left: 6px;padding-right: 6px; } }.modlbx-mfp-ie7 .modlbx-mfp-img {padding: 0; }.modlbx-mfp-ie7 .modlbx-mfp-bottom-bar {width: 600px;left: 50%;margin-left: -300px;margin-top: 5px;padding-bottom: 5px; }.modlbx-mfp-ie7 .modlbx-mfp-container {padding: 0; }.modlbx-mfp-ie7 .modlbx-mfp-content {padding-top: 44px; }.modlbx-mfp-ie7 .modlbx-mfp-close {top: 0;right: 0;padding-top: 0; }.modlbx-mfp-fade.modlbx-mfp-bg {opacity: 0.01;-webkit-transition: all 0.15s ease-out;-moz-transition: all 0.15s ease-out;transition: all 0.15s ease-out;}.modlbx-mfp-fade.modlbx-mfp-bg.modlbx-mfp-ready { }.modlbx-mfp-fade.modlbx-mfp-bg.modlbx-mfp-removing {opacity: 0.01;}.modlbx-mfp-fade.modlbx-mfp-wrap .modlbx-mfp-content {opacity: 0.01;-webkit-transition: all 0.15s ease-out;-moz-transition: all 0.15s ease-out;transition: all 0.15s ease-out;}.modlbx-mfp-fade.modlbx-mfp-wrap.modlbx-mfp-ready .modlbx-mfp-content {opacity: 1;}.modlbx-mfp-fade.modlbx-mfp-wrap.modlbx-mfp-removing .modlbx-mfp-content {opacity: 0.01;}.modlbx-mfp-zoom-in {}.modlbx-mfp-zoom-in .modlbx-mfp-with-anim {opacity: 0.01;transition: all 0.2s ease-in-out;-webkit-transform: scale(0.8);}.modlbx-mfp-zoom-in.modlbx-mfp-bg {opacity: 0.01;transition: all 0.3s ease-out;}.modlbx-mfp-zoom-in.modlbx-mfp-ready .modlbx-mfp-with-anim {opacity: 1;-webkit-transform: scale(1);}.modlbx-mfp-zoom-in.modlbx-mfp-ready.modlbx-mfp-bg {}.modlbx-mfp-zoom-in.modlbx-mfp-removing .modlbx-mfp-with-anim {-webkit-transform: scale(0.8);opacity: 0.01;}.modlbx-mfp-zoom-in.modlbx-mfp-removing.modlbx-mfp-bg {opacity: 0.01;}.modlbx-mfp-newspaper {}.modlbx-mfp-newspaper .modlbx-mfp-with-anim {opacity: 0.01;-webkit-transition: all 0.5s ease-in-out;transition: all 0.5s;-moz-transition: all 0.5s ease-in-out;-webkit-transform: scale(0) rotate(500deg);-moz-transform: scale(0) rotate(500deg);transform: scale(0) rotate(500deg);}.modlbx-mfp-newspaper.modlbx-mfp-bg {opacity: 0.01;transition: all 0.5s;}.modlbx-mfp-newspaper.modlbx-mfp-ready .modlbx-mfp-with-anim {opacity: 1;-webkit-transform: scale(1) rotate(0deg);-moz-transform: scale(1) rotate(0deg);transform: scale(1) rotate(0deg);}.modlbx-mfp-newspaper.modlbx-mfp-removing .modlbx-mfp-with-anim {-webkit-transform: scale(0) rotate(500deg);-moz-transform: scale(0) rotate(500deg);transform: scale(0) rotate(500deg);opacity: 0.01;}.modlbx-mfp-newspaper.modlbx-mfp-removing.modlbx-mfp-bg {opacity: 0.01;}.modlbx-mfp-move-horizontal {}.modlbx-mfp-move-horizontal .modlbx-mfp-with-anim {opacity: 0.01;transition: all 0.3s;-webkit-transform: translateX(-50px);-moz-transform: translateX(-50px);transform: translateX(-50px);}.modlbx-mfp-move-horizontal.modlbx-mfp-bg {opacity: 0.01;transition: all 0.3s;}.modlbx-mfp-move-horizontal.modlbx-mfp-ready .modlbx-mfp-with-anim {opacity: 1;-webkit-transform: translateX(0);-moz-transform: translateX(0);transform: translateX(0);}.modlbx-mfp-move-horizontal.modlbx-mfp-ready.modlbx-mfp-bg {}.modlbx-mfp-move-horizontal.modlbx-mfp-removing .modlbx-mfp-with-anim {-webkit-transform: translateX(50px);-moz-transform: translateX(50px);transform: translateX(50px);opacity: 0.01;}.modlbx-mfp-move-horizontal.modlbx-mfp-removing.modlbx-mfp-bg {opacity: 0.01;}.modlbx-mfp-move-from-top {}.modlbx-mfp-move-from-top .modlbx-mfp-content {vertical-align: top;}.modlbx-mfp-move-from-top .modlbx-mfp-with-anim {opacity: 0.01;transition: all 0.2s;-webkit-transform: translateY(-100px);-moz-transform: translateY(-100px);transform: translateY(-100px);}.modlbx-mfp-move-from-top.modlbx-mfp-bg {opacity: 0;transition: all 0.2s;}.modlbx-mfp-move-from-top.modlbx-mfp-ready .modlbx-mfp-with-anim {opacity: 1;-webkit-transform: translateY(0);-moz-transform: translateY(0);transform: translateY(0);}.modlbx-mfp-move-from-top.modlbx-mfp-ready.modlbx-mfp-bg {}.modlbx-mfp-move-from-top.modlbx-mfp-removing .modlbx-mfp-with-anim {-webkit-transform: translateY(-50px);-moz-transform: translateY(-50px);transform: translateY(-50px);opacity: 0.01;}.modlbx-mfp-move-from-top.modlbx-mfp-removing.modlbx-mfp-bg {opacity: 0.01;}.modlbx-mfp-3d-unfold {}.modlbx-mfp-3d-unfold .modlbx-mfp-content {-webkit-perspective: 2000px;perspective: 2000px;}.modlbx-mfp-3d-unfold .modlbx-mfp-with-anim {opacity: 0.01;-webkit-transition: all 0.3s ease-in-out;-webkit-transform-style: preserve-3d;-webkit-transform: rotateX(-60deg);-moz-transition: all 0.3s ease-in-out;-moz-transform-style: preserve-3d;-moz-transform: rotateX(-60deg);transition: all 0.3s ease-in-out;transform-style: preserve-3d;transform: rotateX(-60deg);}.modlbx-mfp-3d-unfold.modlbx-mfp-bg {opacity: 0.01;transition: all 0.5s;-webkit-transition: all 0.5s;-moz-transition: all 0.5s;}.modlbx-mfp-3d-unfold.modlbx-mfp-ready .modlbx-mfp-with-anim {opacity: 1;-webkit-transform: rotateX(0deg);-moz-transform: rotateX(0deg);transform: rotateX(0deg);}.modlbx-mfp-3d-unfold.modlbx-mfp-ready.modlbx-mfp-bg {}.modlbx-mfp-3d-unfold.modlbx-mfp-removing .modlbx-mfp-with-anim {-webkit-transform: rotateX(60deg);-moz-transform: rotateX(60deg);transform: rotateX(60deg);opacity: 0.01;}.modlbx-mfp-3d-unfold.modlbx-mfp-removing.modlbx-mfp-bg {opacity: 0.01;}.modlbx-mfp-zoom-out {}.modlbx-mfp-zoom-out .modlbx-mfp-with-anim {opacity: 0.01;transition: all 0.3s ease-in-out;-webkit-transform: scale(1.3);-moz-transform: scale(1.3);transform: scale(1.3);}.modlbx-mfp-zoom-out.modlbx-mfp-bg {opacity: 0.01;transition: all 0.3s ease-out;}.modlbx-mfp-zoom-out.modlbx-mfp-ready .modlbx-mfp-with-anim {opacity: 1;-webkit-transform: scale(1);-moz-transform: scale(1);transform: scale(1);}.modlbx-mfp-zoom-out.modlbx-mfp-ready.modlbx-mfp-bg {}.modlbx-mfp-zoom-out.modlbx-mfp-removing .modlbx-mfp-with-anim {-webkit-transform: scale(1.3);-moz-transform: scale(1.3);transform: scale(1.3);opacity: 0.01;}.modlbx-mfp-zoom-out.modlbx-mfp-removing.modlbx-mfp-bg {opacity: 0.01;}@-webkit-keyframes hinge {0% {-webkit-transform: rotate(0);-webkit-transform-origin: top left;-webkit-animation-timing-function: ease-in-out;-moz-transform: rotate(0);-moz-transform-origin: top left;-moz-animation-timing-function: ease-in-out;transform: rotate(0);transform-origin: top left;animation-timing-function: ease-in-out;}20%, 60% {-webkit-transform: rotate(80deg);-webkit-transform-origin: top left;-webkit-animation-timing-function: ease-in-out;-moz-transform: rotate(80deg);-moz-transform-origin: top left;-moz-animation-timing-function: ease-in-out;transform: rotate(80deg);transform-origin: top left;animation-timing-function: ease-in-out;}40% {-webkit-transform: rotate(60deg);-webkit-transform-origin: top left;-webkit-animation-timing-function: ease-in-out;-moz-transform: rotate(60deg);-moz-transform-origin: top left;-moz-animation-timing-function: ease-in-out;transform: rotate(60deg);transform-origin: top left;animation-timing-function: ease-in-out;}80% {opacity: 1;-webkit-transform: rotate(60deg) translateY(0);-webkit-transform-origin: top left;-webkit-animation-timing-function: ease-in-out;-moz-transform: rotate(60deg) translateY(0);-moz-transform-origin: top left;-moz-animation-timing-function: ease-in-out;transform: rotate(60deg) translateY(0);transform-origin: top left;animation-timing-function: ease-in-out;}100% {-webkit-transform: translateY(700px);-moz-transform: translateY(700px);transform: translateY(700px);opacity: 0.01;}}.hinge {-webkit-animation-duration: 1s;-webkit-animation-name: hinge;-moz-animation-duration: 1s;-moz-animation-name: hinge;animation-duration: 1s;animation-name: hinge;}.modlbx-mfp-with-fade .modlbx-mfp-content, .modlbx-mfp-with-fade.modlbx-mfp-bg {opacity: 0.01;transition: opacity .5s ease-out;}.modlbx-mfp-with-fade.modlbx-mfp-ready .modlbx-mfp-content {opacity: 1;}.modlbx-mfp-with-fade.modlbx-mfp-ready.modlbx-mfp-bg {}.modlbx-mfp-with-fade.modlbx-mfp-removing.modlbx-mfp-bg {opacity: 0.01;}.my-modlbx-mfp-slide-bottom .modlbx-mfp-with-anim { opacity: 0.01; -webkit-transition: all 0.5s ease-out; -moz-transition: all 0.5s ease-out; -o-transition: all 0.5s ease-out; transition: all 0.5s ease-out; -webkit-transform: translateY(-20px) perspective( 600px ) rotateX( 10deg ); -moz-transform: translateY(-20px) perspective( 600px ) rotateX( 10deg ); -ms-transform: translateY(-20px) perspective( 600px ) rotateX( 10deg ); -o-transform: translateY(-20px) perspective( 600px ) rotateX( 10deg ); transform: translateY(-20px) perspective( 600px ) rotateX( 10deg );}.my-modlbx-mfp-slide-bottom.modlbx-mfp-ready .modlbx-mfp-with-anim { opacity: 1; -webkit-transform: translateY(0) perspective( 600px ) rotateX( 0 );-moz-transform: translateY(0) perspective( 600px ) rotateX( 0 );-ms-transform: translateY(0) perspective( 600px ) rotateX( 0 );-o-transform: translateY(0) perspective( 600px ) rotateX( 0 );transform: translateY(0) perspective( 600px ) rotateX( 0 ); }.my-modlbx-mfp-slide-bottom.modlbx-mfp-removing .modlbx-mfp-with-anim { opacity: 0.01; -webkit-transform: translateY(-10px) perspective( 600px ) rotateX( 10deg );-moz-transform: translateY(-10px) perspective( 600px ) rotateX( 10deg );-ms-transform: translateY(-10px) perspective( 600px ) rotateX( 10deg );-o-transform: translateY(-10px) perspective( 600px ) rotateX( 10deg );transform: translateY(-10px) perspective( 600px ) rotateX( 10deg ); }.my-modlbx-mfp-slide-bottom.modlbx-mfp-bg { opacity: 0.01; -webkit-transition: opacity 0.3s ease-out;-moz-transition: opacity 0.3s ease-out;-o-transition: opacity 0.3s ease-out;transition: opacity 0.3s ease-out;}.my-modlbx-mfp-slide-bottom.modlbx-mfp-ready.modlbx-mfp-bg { }.my-modlbx-mfp-slide-bottom.modlbx-mfp-removing.modlbx-mfp-bg { opacity: 0.01;}.modlbx-mfp-ready.modlbx-mfp-bg {opacity: 0.85;filter: alpha(opacity = 85);};
/*
 * jQuery FlexSlider v2.2.0
 * http://www.woothemes.com/flexslider/
 *
 * Copyright 2012 WooThemes
 * Free to use under the GPLv2 license.
 * http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Contributing author: Tyler Smith (@mbmufffin)
 */
.lookbook-modmedia-container .fflex-container a:active,
.lookbook-modmedia-container .fflexslider a:active,
.lookbook-modmedia-container .fflex-container a:focus,
.lookbook-modmedia-container .lookbook-modmedia-flexslider a:focus  {outline: none;}
.lookbook-modmedia-container .lookbook_slides,
.lookbook-modmedia-container .fflex-control-nav,
.lookbook-modmedia-container .fflex-direction-nav {margin: 0; padding: 0; list-style: none; position:inherit; top:auto; width:auto;}
.lookbook-modmedia-container ul.fflex-direction-nav li{position:static; margin:0px; padding:0px; content:''; }
.lookbook-modmedia-container ul.fflex-direction-nav li:before{margin:0px; padding:0px; content:''; }
.lookbook-modmedia-container .fflex-direction-nav li{position:inherit;}
.lookbook-modmedia-container .lookbook-modmedia-flexslider {margin: 0; padding: 0;}
.lookbook-modmedia-container .lookbook-modmedia-flexslider .lookbook_slides > li {display: none; -webkit-backface-visibility: hidden; margin:0px;  text-align:center;} 
/* Hide the slides before the JS is loaded. Avoids image jumping */
.lookbook-modmedia-container .lookbook-modmedia-flexslider .lookbook_slides img {/*width: 100%; display: block;*/}
.lookbook-modmedia-container .fflex-pauseplay span {text-transform: capitalize;}
.lookbook-modmedia-container .lookbook_slides:after {content: '\0020'; display: block; clear: both; visibility: hidden; line-height: 0; height: 0;}
html[xmlns] .lookbook-modmedia-container .lookbook_slides {display: block;}
* html .lookbook-modmedia-container .lookbook_slides {height: 1%;}
.no-js .lookbook-modmedia-container .lookbook_slides > li:first-child {display: block;}
.lookbook-modmedia-container .fflexslider { margin: 0 0 60px; background: #fff; border: 4px solid #fff; position: relative; -webkit-border-radius: 4px; -moz-border-radius: 4px; -o-border-radius: 4px; border-radius: 4px; -webkit-box-shadow: 0 1px 4px rgba(0,0,0,.2); -moz-box-shadow: 0 1px 4px rgba(0,0,0,.2); -o-box-shadow: 0 1px 4px rgba(0,0,0,.2); box-shadow: 0 1px 4px rgba(0,0,0,.2); zoom: 1; }
.lookbook-modmedia-container .fflex-viewport { -webkit-transition: all 1s ease; -moz-transition: all 1s ease; -o-transition: all 1s ease; transition: all 1s ease; }
.lookbook-modmedia-container .loading .fflex-viewport { max-height: 300px; }
.lookbook-modmedia-container .fflexslider .lookbook_slides { zoom: 1; }
.lookbook-modmedia-container .carousel li { margin-right: 5px; }
/* Direction Nav */
.lookbook-modmedia-container .fflex-direction-nav {*height: 0;}
.lookbook-modmedia-container .fflex-direction-nav a  { display: block; width: auto; position: absolute; top: 50%; z-index: 10; overflow: hidden; opacity: 0; cursor: pointer; color: rgba(0,0,0,0.8); text-shadow: 1px 1px 0 rgba(255,255,255,0.3); -webkit-transition: all .3s ease; -moz-transition: all .3s ease; transition: all .3s ease; }
.lookbook-modmedia-container .fflex-direction-nav .fflex-prev { left: -80px; }
.lookbook-modmedia-container .fflex-direction-nav .fflex-next { right: -50px; text-align: right; }
.lookbook-modmedia-container .fflexslider:hover .fflex-prev { opacity: 0.7; left: 10px; }
.lookbook-modmedia-container .fflexslider:hover .fflex-next { opacity: 0.7; right: 10px; }
.lookbook-modmedia-container .fflexslider:hover .fflex-next:hover, .lookbook-modmedia-container .fflexslider:hover .fflex-prev:hover { opacity: 1; }
.lookbook-modmedia-container .fflex-direction-nav .fflex-disabled { opacity: 0!important; filter:alpha(opacity=0); cursor: default; }
.lookbook-modmedia-container .fflex-direction-nav a:before  { }
.lookbook-modmedia-container .fflex-direction-nav a.fflex-next:before  {  }
/* Pause/Play */
.lookbook-modmedia-container .fflex-pauseplay a { display: block; width: 20px; height: 20px; position: absolute; bottom: 5px; left: 10px; opacity: 0.8; z-index: 10; overflow: hidden; cursor: pointer; color: #000; }
.lookbook-modmedia-container .fflex-pauseplay a:before  { font-size: 20px; display: inline-block;  }
.lookbook-modmedia-container .fflex-pauseplay a:hover  { opacity: 1; }
.lookbook-modmedia-container .fflex-pauseplay a.fflex-play:before { }
/* Control Nav */
.lookbook-modmedia-container .fflex-control-nav {width: 100%; text-align: center; padding:10px 0px; position:relative; bottom:inherit;/*position:absolute; bottom:-40px;*/}
.lookbook-modmedia-container .fflex-control-nav li {margin: 0 6px; display: inline-block; zoom: 1; *display: inline;}
.lookbook-modmedia-container .fflex-control-paging li a {width: 11px; height: 11px; display: block; background: #666; background: rgba(0,0,0,0.5); cursor: pointer; text-indent: -9999px; -webkit-border-radius: 20px; -moz-border-radius: 20px; -o-border-radius: 20px; border-radius: 20px; -webkit-box-shadow: inset 1px 1px 3px rgba(0,0,0,0.8); -moz-box-shadow: inset 1px 1px 3px rgba(0,0,0,0.8); -o-box-shadow: inset 1px 1px 3px rgba(0,0,0,0.8); box-shadow: inset 1px 1px 3px rgba(0,0,0,0.8); }
.lookbook-modmedia-container .fflex-control-paging li a:hover { background: #D4521F; }
.lookbook-modmedia-container .fflex-control-paging li a.fflex-active { background: #ed6647; cursor: default; }
.lookbook-modmedia-container .fflex-control-thumbs {margin: 5px 0 0; position: static; overflow: hidden;}
.lookbook-modmedia-container .fflex-control-thumbs li {width: 25%; float: left; margin: 0;}
.lookbook-modmedia-container .fflex-control-thumbs img {width: 100%; display: block; opacity: .7; cursor: pointer;}
.lookbook-modmedia-container .fflex-control-thumbs img:hover {opacity: 1;}
.lookbook-modmedia-container .fflex-control-thumbs .fflex-active {opacity: 1; cursor: default;}
.lookbook-modmedia-container:hover .fflex-direction-nav .fflex-prev { opacity: 1; left: 20px;}
.lookbook-modmedia-container:hover .fflex-direction-nav .fflex-next { opacity: 1; right: 20px;}
@media screen and (max-width: 860px) {
  .lookbook-modmedia-container .fflex-direction-nav .fflex-prev { opacity: 1; left: 10px;}
  .lookbook-modmedia-container .fflex-direction-nav .fflex-next { opacity: 1; right: 10px;}
};